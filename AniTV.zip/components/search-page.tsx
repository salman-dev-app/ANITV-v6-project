"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { SearchIcon, Filter, X } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
  SheetClose,
} from "@/components/ui/sheet"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

// Mock data - would come from Supabase in production
const animeData = [
  {
    id: 1,
    title: "Demon Slayer",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "AnimeAdmin",
    genre: ["Action", "Fantasy"],
    views: 1250000,
  },
  {
    id: 2,
    title: "Attack on Titan",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "MangaLover",
    genre: ["Action", "Drama"],
    views: 980000,
  },
  {
    id: 3,
    title: "My Hero Academia",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "SuperheroFan",
    genre: ["Action", "Superhero"],
    views: 870000,
  },
  {
    id: 4,
    title: "Jujutsu Kaisen",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "AnimeAdmin",
    genre: ["Action", "Supernatural"],
    views: 760000,
  },
  {
    id: 5,
    title: "Chainsaw Man",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "MangaLover",
    genre: ["Action", "Horror"],
    views: 650000,
  },
  {
    id: 6,
    title: "Spy x Family",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "ComedyFan",
    genre: ["Comedy", "Action"],
    views: 540000,
  },
  {
    id: 7,
    title: "One Piece",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "PirateKing",
    genre: ["Adventure", "Fantasy"],
    views: 1500000,
  },
  {
    id: 8,
    title: "Bleach: Thousand-Year Blood War",
    poster: "/placeholder.svg?height=300&width=200",
    uploader: "SoulReaper",
    genre: ["Action", "Supernatural"],
    views: 430000,
  },
]

const genres = [
  "Action",
  "Adventure",
  "Comedy",
  "Drama",
  "Fantasy",
  "Horror",
  "Mystery",
  "Romance",
  "Sci-Fi",
  "Slice of Life",
  "Sports",
  "Supernatural",
  "Thriller",
]
const uploaders = ["All Uploaders", "AnimeAdmin", "MangaLover", "SuperheroFan", "ComedyFan", "PirateKing", "SoulReaper"]
const sortOptions = ["Most Viewed", "Recently Added", "Alphabetical"]

export default function SearchPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const initialQuery = searchParams.get("q") || ""
  const initialGenre = searchParams.get("genre") || ""

  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [selectedGenres, setSelectedGenres] = useState<string[]>(initialGenre ? [initialGenre] : [])
  const [selectedUploader, setSelectedUploader] = useState("All Uploaders")
  const [sortBy, setSortBy] = useState("Most Viewed")
  const [loading, setLoading] = useState(true)
  const [results, setResults] = useState<typeof animeData>([])

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    filterResults()
  }

  // Filter results based on search criteria
  const filterResults = () => {
    setLoading(true)

    // In a real app, this would be a Supabase query
    setTimeout(() => {
      let filtered = [...animeData]

      // Filter by search query
      if (searchQuery) {
        filtered = filtered.filter((anime) => anime.title.toLowerCase().includes(searchQuery.toLowerCase()))
      }

      // Filter by genres
      if (selectedGenres.length > 0) {
        filtered = filtered.filter((anime) => selectedGenres.some((genre) => anime.genre.includes(genre)))
      }

      // Filter by uploader
      if (selectedUploader !== "All Uploaders") {
        filtered = filtered.filter((anime) => anime.uploader === selectedUploader)
      }

      // Sort results
      if (sortBy === "Most Viewed") {
        filtered.sort((a, b) => b.views - a.views)
      } else if (sortBy === "Alphabetical") {
        filtered.sort((a, b) => a.title.localeCompare(b.title))
      }
      // For "Recently Added" we would need a timestamp field

      setResults(filtered)
      setLoading(false)
    }, 500)
  }

  // Toggle genre selection
  const toggleGenre = (genre: string) => {
    setSelectedGenres((prev) => (prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]))
  }

  // Clear all filters
  const clearFilters = () => {
    setSelectedGenres([])
    setSelectedUploader("All Uploaders")
    setSortBy("Most Viewed")
  }

  // Apply filters
  const applyFilters = () => {
    filterResults()
  }

  // Initial load
  useEffect(() => {
    filterResults()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Search Anime</h1>

      {/* Search bar */}
      <div className="flex items-center gap-2 mb-6">
        <form onSubmit={handleSearch} className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              type="search"
              placeholder="Search anime..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
            Search
          </Button>
        </form>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
              <SheetDescription>Refine your search results</SheetDescription>
            </SheetHeader>

            <div className="py-4 space-y-6">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Sort By</h3>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Uploader</h3>
                <Select value={selectedUploader} onValueChange={setSelectedUploader}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select uploader" />
                  </SelectTrigger>
                  <SelectContent>
                    {uploaders.map((uploader) => (
                      <SelectItem key={uploader} value={uploader}>
                        {uploader}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">Genres</h3>
                  {selectedGenres.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedGenres([])}
                      className="h-auto p-0 text-xs text-muted-foreground"
                    >
                      Clear
                    </Button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {genres.map((genre) => (
                    <div key={genre} className="flex items-center space-x-2">
                      <Checkbox
                        id={`genre-${genre}`}
                        checked={selectedGenres.includes(genre)}
                        onCheckedChange={() => toggleGenre(genre)}
                      />
                      <Label htmlFor={`genre-${genre}`} className="text-sm">
                        {genre}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <SheetFooter className="flex flex-row gap-2 sm:justify-end">
              <SheetClose asChild>
                <Button variant="outline" onClick={clearFilters}>
                  Reset
                </Button>
              </SheetClose>
              <SheetClose asChild>
                <Button className="bg-orange-500 hover:bg-orange-600" onClick={applyFilters}>
                  Apply Filters
                </Button>
              </SheetClose>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      </div>

      {/* Active filters */}
      {selectedGenres.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {selectedGenres.map((genre) => (
            <Badge
              key={genre}
              variant="secondary"
              className="flex items-center gap-1 bg-orange-500/10 text-orange-500 border-orange-500/50"
            >
              {genre}
              <button onClick={() => toggleGenre(genre)} className="ml-1 rounded-full">
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
          {selectedGenres.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="h-6 px-2 text-xs">
              Clear All
            </Button>
          )}
        </div>
      )}

      {/* Results count */}
      <div className="text-sm text-muted-foreground mb-4">
        {loading ? "Searching..." : `${results.length} results found`}
      </div>

      {/* Results grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {loading ? (
          // Loading skeletons
          Array(8)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-[200px] w-full rounded-md" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
              </div>
            ))
        ) : results.length > 0 ? (
          // Results
          results.map((anime) => (
            <Link key={anime.id} href={`/anime/${anime.id}`} className="transition-transform hover:scale-105">
              <Card className="border-0 overflow-hidden">
                <div className="relative aspect-[2/3] w-full">
                  <Image
                    src={anime.poster || "/placeholder.svg"}
                    alt={anime.title}
                    fill
                    className="object-cover rounded-t-md"
                  />
                </div>
                <CardContent className="p-2">
                  <h3 className="font-medium line-clamp-1">{anime.title}</h3>
                  <p className="text-xs text-muted-foreground">By {anime.uploader}</p>
                </CardContent>
              </Card>
            </Link>
          ))
        ) : (
          // No results
          <div className="col-span-full text-center py-12">
            <div className="text-muted-foreground">No results found</div>
            <Button variant="link" onClick={clearFilters} className="mt-2">
              Clear filters and try again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
