"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/components/auth-provider"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { createClient } from "@/lib/supabase/client"
import { ImageIcon } from "lucide-react"

interface ProfileEditProps {
  onCancel: () => void
}

export default function ProfileEdit({ onCancel }: ProfileEditProps) {
  const { toast } = useToast()
  const { user, isLoading, refreshUser } = useAuth()
  const supabase = createClient()

  const [name, setName] = useState(user?.user_metadata?.name || "")
  const [avatarUrl, setAvatarUrl] = useState(user?.user_metadata?.avatar_url || "")
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      })
      return
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 2MB",
        variant: "destructive",
      })
      return
    }

    setAvatarFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setAvatarPreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    setIsSubmitting(true)

    try {
      let finalAvatarUrl = avatarUrl

      // Upload avatar if a new one was selected
      if (avatarFile && supabase) {
        const fileName = `avatar-${Date.now()}-${avatarFile.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`

        // Create form data for upload
        const formData = new FormData()
        formData.append("file", avatarFile)
        formData.append("bucket", "avatars")
        formData.append("path", "public")

        // Use fetch to upload with progress tracking
        const xhr = new XMLHttpRequest()
        xhr.open("POST", "/api/storage", true)

        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const progress = Math.round((event.loaded / event.total) * 100)
            setUploadProgress(progress)
          }
        }

        xhr.onload = async () => {
          if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText)
            finalAvatarUrl = response.url
            setUploadProgress(0)

            // Continue with profile update
            await updateProfile(finalAvatarUrl)
          } else {
            console.error("Upload failed:", xhr.responseText)
            toast({
              title: "Upload failed",
              description: "There was an error uploading the image. Please try again.",
              variant: "destructive",
            })
            setUploadProgress(0)
            setIsSubmitting(false)
          }
        }

        xhr.onerror = () => {
          console.error("Upload error")
          toast({
            title: "Upload failed",
            description: "There was a network error. Please try again.",
            variant: "destructive",
          })
          setUploadProgress(0)
          setIsSubmitting(false)
        }

        xhr.send(formData)
      } else {
        // No new avatar, just update profile
        await updateProfile(finalAvatarUrl)
      }
    } catch (error: any) {
      console.error("Profile update error:", error)
      toast({
        title: "Error updating profile",
        description: error.message || "An error occurred while updating your profile",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  const updateProfile = async (avatarUrl: string) => {
    try {
      // Update user metadata via API route
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          avatar_url: avatarUrl,
        }),
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.error || "Failed to update profile")
      }

      await refreshUser()

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      })

      onCancel()
    } catch (error: any) {
      console.error("Profile update error:", error)
      toast({
        title: "Error updating profile",
        description: error.message || "An error occurred while updating your profile",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <form onSubmit={handleSubmit} className="p-6 space-y-6">
      <div className="flex flex-col items-center gap-4">
        <Avatar className="h-24 w-24">
          <AvatarImage src={avatarPreview || avatarUrl || "/placeholder.svg"} alt={name || user?.email || "User"} />
          <AvatarFallback>{name?.[0]?.toUpperCase() || user?.email?.[0].toUpperCase() || "U"}</AvatarFallback>
        </Avatar>

        {uploadProgress > 0 && uploadProgress < 100 && (
          <div className="w-full max-w-xs bg-secondary rounded-full h-2.5 dark:bg-secondary">
            <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
            <p className="text-xs text-center mt-1">{uploadProgress}%</p>
          </div>
        )}

        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2"
          disabled={isSubmitting || (uploadProgress > 0 && uploadProgress < 100)}
        >
          <ImageIcon className="h-4 w-4" />
          Change Avatar
        </Button>
        <input type="file" ref={fileInputRef} onChange={handleAvatarSelect} accept="image/*" className="hidden" />
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Display Name</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your display name"
            disabled={isSubmitting}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={user?.email || ""} disabled className="bg-muted" />
          <p className="text-xs text-muted-foreground">Email cannot be changed</p>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isSubmitting || (uploadProgress > 0 && uploadProgress < 100)}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-orange-500 hover:bg-orange-600"
          disabled={isSubmitting || (uploadProgress > 0 && uploadProgress < 100)}
        >
          {isSubmitting ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </form>
  )
}
