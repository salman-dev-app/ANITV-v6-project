"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import BottomNav from "@/components/bottom-nav"
import ProtectedRoute from "@/components/protected-route"
import AppHeader from "@/components/app-header"

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  // Don't apply protected route to auth page
  if (pathname === "/auth") {
    return (
      <div className="flex flex-col min-h-screen bg-background">
        <main className="flex-1">{children}</main>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="flex flex-col min-h-screen bg-background">
        <AppHeader />
        <main className="flex-1 pb-16">{children}</main>
        <BottomNav />
      </div>
    </ProtectedRoute>
  )
}
