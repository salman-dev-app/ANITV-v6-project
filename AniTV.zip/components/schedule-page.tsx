"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { format, addDays, startOfWeek } from "date-fns"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data - would come from Supabase in production
const scheduleData = [
  {
    id: 1,
    title: "Demon Slayer",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-10",
    type: "TV",
    genre: ["Action", "Fantasy"],
  },
  {
    id: 2,
    title: "Attack on Titan",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-11",
    type: "TV",
    genre: ["Action", "Drama"],
  },
  {
    id: 3,
    title: "My Hero Academia",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-12",
    type: "TV",
    genre: ["Action", "Superhero"],
  },
  {
    id: 4,
    title: "Jujutsu Kaisen",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-13",
    type: "TV",
    genre: ["Action", "Supernatural"],
  },
  {
    id: 5,
    title: "One Piece Movie: Red",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-14",
    type: "Movie",
    genre: ["Adventure", "Fantasy"],
  },
  {
    id: 6,
    title: "Chainsaw Man OVA",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-15",
    type: "OVA",
    genre: ["Action", "Horror"],
  },
  {
    id: 7,
    title: "Spy x Family",
    poster: "/placeholder.svg?height=150&width=100",
    releaseDate: "2023-05-16",
    type: "TV",
    genre: ["Comedy", "Action"],
  },
]

const genres = ["All Genres", "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Supernatural"]
const types = ["All Types", "TV", "Movie", "OVA"]

export default function SchedulePage() {
  const today = new Date()
  const weekStart = startOfWeek(today, { weekStartsOn: 1 }) // Start from Monday
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))

  const [selectedDay, setSelectedDay] = useState(format(today, "yyyy-MM-dd"))
  const [selectedGenre, setSelectedGenre] = useState("All Genres")
  const [selectedType, setSelectedType] = useState("All Types")

  // Filter anime based on selected filters
  const filteredAnime = scheduleData.filter((anime) => {
    const matchesDay = anime.releaseDate === selectedDay
    const matchesGenre = selectedGenre === "All Genres" || anime.genre.includes(selectedGenre)
    const matchesType = selectedType === "All Types" || anime.type === selectedType
    return matchesDay && matchesGenre && matchesType
  })

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Weekly Schedule</h1>

      {/* Day selector tabs */}
      <Tabs defaultValue={selectedDay} onValueChange={setSelectedDay} className="mb-6">
        <TabsList className="w-full overflow-x-auto flex justify-start p-0 h-auto bg-transparent">
          {weekDays.map((day) => {
            const formattedDate = format(day, "yyyy-MM-dd")
            const isToday = format(today, "yyyy-MM-dd") === formattedDate
            return (
              <TabsTrigger
                key={formattedDate}
                value={formattedDate}
                className={`flex flex-col py-2 px-4 ${isToday ? "border-b-2 border-orange-500" : ""}`}
              >
                <span className="text-xs">{format(day, "EEE")}</span>
                <span className={`text-lg font-semibold ${isToday ? "text-orange-500" : ""}`}>{format(day, "d")}</span>
              </TabsTrigger>
            )
          })}
        </TabsList>

        {/* Filters */}
        <div className="flex gap-4 mb-6">
          <Select value={selectedGenre} onValueChange={setSelectedGenre}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select Genre" />
            </SelectTrigger>
            <SelectContent>
              {genres.map((genre) => (
                <SelectItem key={genre} value={genre}>
                  {genre}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select Type" />
            </SelectTrigger>
            <SelectContent>
              {types.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Schedule content for each day */}
        {weekDays.map((day) => {
          const formattedDate = format(day, "yyyy-MM-dd")
          return (
            <TabsContent key={formattedDate} value={formattedDate} className="mt-0">
              <div className="space-y-4">
                {filteredAnime.length > 0 ? (
                  filteredAnime.map((anime) => (
                    <Link key={anime.id} href={`/anime/${anime.id}`}>
                      <Card className="overflow-hidden hover:bg-accent/50 transition-colors">
                        <CardContent className="p-4 flex items-center gap-4">
                          <div className="relative h-[100px] w-[70px] shrink-0">
                            <Image
                              src={anime.poster || "/placeholder.svg"}
                              alt={anime.title}
                              fill
                              className="object-cover rounded-md"
                            />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold">{anime.title}</h3>
                            <div className="flex gap-2 mt-2">
                              <Badge
                                variant="outline"
                                className="bg-orange-500/10 text-orange-500 border-orange-500/50"
                              >
                                {anime.type}
                              </Badge>
                              {anime.genre.map((g) => (
                                <Badge key={g} variant="secondary" className="bg-secondary/50">
                                  {g}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No anime scheduled for this day with the selected filters.
                  </div>
                )}
              </div>
            </TabsContent>
          )
        })}
      </Tabs>
    </div>
  )
}
