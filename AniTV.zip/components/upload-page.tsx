"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { PlusCircle, Trash2, UploadIcon, ImageIcon } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { MultiSelect } from "@/components/multi-select"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/components/auth-provider"
import Image from "next/image"

// Mock genres for the multi-select
const genreOptions = [
  { label: "Action", value: "action" },
  { label: "Adventure", value: "adventure" },
  { label: "Comedy", value: "comedy" },
  { label: "Drama", value: "drama" },
  { label: "Fantasy", value: "fantasy" },
  { label: "Horror", value: "horror" },
  { label: "Mystery", value: "mystery" },
  { label: "Romance", value: "romance" },
  { label: "Sci-Fi", value: "sci-fi" },
  { label: "Slice of Life", value: "slice-of-life" },
  { label: "Sports", value: "sports" },
  { label: "Supernatural", value: "supernatural" },
  { label: "Thriller", value: "thriller" },
]

interface Episode {
  id: string
  title: string
  videoUrl: string
}

export default function UploadPage() {
  const { toast } = useToast()
  const router = useRouter()
  const { user } = useAuth()
  const supabase = createClient()

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [posterUrl, setPosterUrl] = useState("")
  const [selectedGenres, setSelectedGenres] = useState<{ label: string; value: string }[]>([])
  const [episodes, setEpisodes] = useState<Episode[]>([{ id: "1", title: "", videoUrl: "" }])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const [posterFile, setPosterFile] = useState<File | null>(null)
  const [posterPreview, setPosterPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const addEpisode = () => {
    setEpisodes([...episodes, { id: Date.now().toString(), title: "", videoUrl: "" }])
  }

  const removeEpisode = (id: string) => {
    if (episodes.length > 1) {
      setEpisodes(episodes.filter((episode) => episode.id !== id))
    } else {
      toast({
        title: "Cannot remove",
        description: "You need at least one episode",
        variant: "destructive",
      })
    }
  }

  const updateEpisode = (id: string, field: keyof Episode, value: string) => {
    setEpisodes(episodes.map((episode) => (episode.id === id ? { ...episode, [field]: value } : episode)))
  }

  const handlePosterSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      })
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setPosterFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setPosterPreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)

    // Upload to Supabase Storage
    try {
      if (!supabase) {
        throw new Error("Supabase client not initialized")
      }

      const { data: userData } = await supabase.auth.getUser()
      if (!userData.user) throw new Error("Not authenticated")

      const fileName = `poster-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`

      // Create form data for upload
      const formData = new FormData()
      formData.append("file", file)
      formData.append("bucket", "posters")
      formData.append("path", "public")

      // Use fetch to upload with progress tracking
      const xhr = new XMLHttpRequest()
      xhr.open("POST", "/api/storage", true)

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const progress = Math.round((event.loaded / event.total) * 100)
          setUploadProgress(progress)
        }
      }

      xhr.onload = async () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText)
          setPosterUrl(response.url)
          setUploadProgress(0)

          toast({
            title: "Image uploaded",
            description: "Poster image uploaded successfully",
          })
        } else {
          console.error("Upload failed:", xhr.responseText)
          toast({
            title: "Upload failed",
            description: "There was an error uploading the image. Please try again.",
            variant: "destructive",
          })
          setUploadProgress(0)
        }
      }

      xhr.onerror = () => {
        console.error("Upload error")
        toast({
          title: "Upload failed",
          description: "There was a network error. Please try again.",
          variant: "destructive",
        })
        setUploadProgress(0)
      }

      xhr.send(formData)
    } catch (error) {
      console.error("Poster upload error:", error)
      toast({
        title: "Poster upload failed",
        description: "There was an error uploading the poster image. Please try again.",
        variant: "destructive",
      })
      setUploadProgress(0)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!title || !description || !posterUrl || selectedGenres.length === 0) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Validate episodes
    const invalidEpisodes = episodes.some((ep) => !ep.title || !ep.videoUrl)
    if (invalidEpisodes) {
      toast({
        title: "Invalid episodes",
        description: "Please fill in all episode details",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Get current user
      if (!user) {
        throw new Error("Not authenticated")
      }

      if (!supabase) {
        throw new Error("Supabase client not initialized")
      }

      // Insert anime
      const { data: animeData, error: animeError } = await supabase
        .from("anime")
        .insert({
          title,
          description,
          poster_url: posterUrl,
          uploader_id: user.id,
          views: 0,
        })
        .select()

      if (animeError) throw animeError

      if (!animeData || animeData.length === 0) {
        throw new Error("Failed to create anime entry")
      }

      const animeId = animeData[0].id

      // Insert episodes
      for (const episode of episodes) {
        const { error: episodeError } = await supabase.from("episodes").insert({
          anime_id: animeId,
          title: episode.title,
          video_url: episode.videoUrl,
          episode_number: Number.parseInt(episode.id),
        })

        if (episodeError) throw episodeError
      }

      // Insert genre relationships
      for (const genre of selectedGenres) {
        // Get genre ID
        const { data: genreData, error: genreError } = await supabase
          .from("genres")
          .select("id")
          .eq("name", genre.label)
          .single()

        if (genreError) throw genreError

        // Insert anime-genre relationship
        const { error: relationError } = await supabase.from("anime_genres").insert({
          anime_id: animeId,
          genre_id: genreData.id,
        })

        if (relationError) throw relationError
      }

      toast({
        title: "Upload successful!",
        description: "Your anime has been uploaded successfully",
      })

      // Reset form
      setTitle("")
      setDescription("")
      setPosterUrl("")
      setPosterPreview(null)
      setPosterFile(null)
      setSelectedGenres([])
      setEpisodes([{ id: "1", title: "", videoUrl: "" }])

      // Redirect to the anime page
      router.push(`/anime/${animeId}`)
    } catch (error: any) {
      console.error("Upload error:", error)
      toast({
        title: "Upload failed",
        description: error.message || "There was an error uploading your anime. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-3xl">
      <h1 className="text-2xl font-bold mb-6">Upload Anime</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Anime Details</CardTitle>
            <CardDescription>Fill in the details about the anime you want to upload</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Anime Title</Label>
              <Input
                id="title"
                placeholder="Enter anime title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Enter anime description"
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="posterUrl">Poster Image</Label>
              <div className="flex flex-col gap-4">
                {posterPreview ? (
                  <div className="relative w-40 h-60 mx-auto border rounded-md overflow-hidden">
                    <Image
                      src={posterPreview || "/placeholder.svg"}
                      alt="Poster preview"
                      fill
                      className="object-cover"
                    />
                    {uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="text-white font-bold">{uploadProgress}%</div>
                      </div>
                    )}
                  </div>
                ) : posterUrl ? (
                  <div className="relative w-40 h-60 mx-auto border rounded-md overflow-hidden">
                    <Image src={posterUrl || "/placeholder.svg"} alt="Poster preview" fill className="object-cover" />
                  </div>
                ) : null}

                <div className="flex flex-col sm:flex-row gap-2">
                  <Input
                    id="posterUrl"
                    placeholder="Enter poster image URL"
                    value={posterUrl}
                    onChange={(e) => setPosterUrl(e.target.value)}
                    className="flex-1"
                  />
                  <span className="text-center text-sm text-muted-foreground my-2 hidden sm:block">OR</span>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2"
                    disabled={uploadProgress > 0 && uploadProgress < 100}
                  >
                    <ImageIcon className="h-4 w-4" />
                    Upload Image
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handlePosterSelect}
                    accept="image/*"
                    className="hidden"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="genres">Genres</Label>
              <MultiSelect
                options={genreOptions}
                selected={selectedGenres}
                onChange={setSelectedGenres}
                placeholder="Select genres"
              />
            </div>

            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Episodes</h3>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addEpisode}
                  className="flex items-center gap-1"
                >
                  <PlusCircle className="h-4 w-4" />
                  Add Episode
                </Button>
              </div>

              {episodes.map((episode, index) => (
                <div key={episode.id} className="space-y-4 p-4 border rounded-md">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Episode {index + 1}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeEpisode(episode.id)}
                      disabled={episodes.length === 1}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`episode-title-${episode.id}`}>Episode Title</Label>
                    <Input
                      id={`episode-title-${episode.id}`}
                      placeholder="Enter episode title"
                      value={episode.title}
                      onChange={(e) => updateEpisode(episode.id, "title", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`episode-url-${episode.id}`}>Video URL</Label>
                    <Input
                      id={`episode-url-${episode.id}`}
                      placeholder="Enter video URL (YouTube, MP4, etc.)"
                      value={episode.videoUrl}
                      onChange={(e) => updateEpisode(episode.id, "videoUrl", e.target.value)}
                      required
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600"
              disabled={isSubmitting || (uploadProgress > 0 && uploadProgress < 100)}
            >
              {isSubmitting ? (
                <>
                  <UploadIcon className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <UploadIcon className="mr-2 h-4 w-4" />
                  Upload Anime
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
