"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import Loading from "@/components/loading"

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [isRedirecting, setIsRedirecting] = useState(false)

  useEffect(() => {
    if (!isLoading && !user) {
      setIsRedirecting(true)
      router.push("/auth")
    }
  }, [user, isLoading, router])

  if (isLoading || isRedirecting) {
    return <Loading message={isRedirecting ? "Redirecting to login..." : "Loading your profile..."} />
  }

  if (!user) {
    return null
  }

  return <>{children}</>
}
