"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Check, X, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { useAuth } from "@/components/auth-provider"
import { createClient } from "@/lib/supabase/client"

export default function AdminDashboard() {
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()
  const supabase = createClient()

  const [reports, setReports] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [stats, setStats] = useState<any>({})
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    async function checkAdminStatus() {
      if (!user) {
        router.push("/auth")
        return
      }

      try {
        // In a real app, you would check if the user has admin role
        // For now, we'll just simulate this check
        const isUserAdmin = user.email === "admin@example.com"
        setIsAdmin(isUserAdmin)

        if (!isUserAdmin) {
          toast({
            title: "Access denied",
            description: "You don't have permission to access the admin dashboard",
            variant: "destructive",
          })
          router.push("/")
        }
      } catch (error) {
        console.error("Admin check error:", error)
        router.push("/")
      }
    }

    checkAdminStatus()
  }, [user, router, toast])

  useEffect(() => {
    async function loadAdminData() {
      if (!isAdmin) return

      try {
        setLoading(true)

        // Fetch reports
        const { data: reportData, error: reportError } = await supabase
          .from("reports")
          .select(`
            id,
            reason,
            created_at,
            resolved,
            anime:anime_id (
              id,
              title
            ),
            user:user_id (
              id,
              email
            )
          `)
          .order("created_at", { ascending: false })

        if (reportError) throw reportError

        // Fetch users
        const { data: userData, error: userError } = await supabase
          .from("auth.users")
          .select("id, email, created_at")
          .order("created_at", { ascending: false })
          .limit(10)

        // Since we can't directly query auth.users in this demo, we'll use mock data
        const mockUsers = [
          { id: "1", email: "user1@example.com", created_at: new Date().toISOString() },
          { id: "2", email: "user2@example.com", created_at: new Date().toISOString() },
          { id: "3", email: "admin@example.com", created_at: new Date().toISOString() },
        ]

        // Fetch stats
        const { data: animeCount, error: animeError } = await supabase
          .from("anime")
          .select("id", { count: "exact", head: true })

        const { data: userCount, error: userCountError } = await supabase
          .from("auth.users")
          .select("id", { count: "exact", head: true })

        // Mock stats
        const mockStats = {
          animeCount: animeCount?.length || 5,
          userCount: 3,
          totalViews: 3500000,
          reportCount: reportData?.length || 0,
        }

        setReports(reportData || [])
        setUsers(userData || mockUsers)
        setStats(mockStats)
      } catch (error) {
        console.error("Error loading admin data:", error)
        toast({
          title: "Error loading data",
          description: "There was a problem loading the admin dashboard data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadAdminData()
  }, [isAdmin, supabase, toast])

  const handleResolveReport = async (reportId: number, resolved: boolean) => {
    try {
      const { error } = await supabase.from("reports").update({ resolved }).eq("id", reportId)

      if (error) throw error

      // Update local state
      setReports(reports.map((report) => (report.id === reportId ? { ...report, resolved } : report)))

      toast({
        title: resolved ? "Report resolved" : "Report reopened",
        description: resolved ? "The report has been marked as resolved" : "The report has been reopened",
      })
    } catch (error) {
      console.error("Error updating report:", error)
      toast({
        title: "Action failed",
        description: "There was an error updating the report status",
        variant: "destructive",
      })
    }
  }

  const handleDeleteAnime = async (animeId: number) => {
    try {
      const { error } = await supabase.from("anime").delete().eq("id", animeId)

      if (error) throw error

      // Update local state - remove all reports for this anime
      setReports(reports.filter((report) => report.anime.id !== animeId))

      toast({
        title: "Anime deleted",
        description: "The anime has been deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting anime:", error)
      toast({
        title: "Delete failed",
        description: "There was an error deleting the anime",
        variant: "destructive",
      })
    }
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-6 text-center">
        <AlertTriangle className="h-12 w-12 mx-auto text-orange-500 mb-4" />
        <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
        <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
        <Button asChild>
          <a href="/">Return to Home</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Anime</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-8 w-16" /> : <p className="text-2xl font-bold">{stats.animeCount}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-8 w-16" /> : <p className="text-2xl font-bold">{stats.userCount}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <p className="text-2xl font-bold">{(stats.totalViews / 1000000).toFixed(1)}M</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Open Reports</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <p className="text-2xl font-bold">{reports.filter((r) => !r.resolved).length}</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="reports" className="w-full">
        <TabsList className="w-full max-w-md mx-auto grid grid-cols-2 mb-8">
          <TabsTrigger value="reports">Content Reports</TabsTrigger>
          <TabsTrigger value="users">Recent Users</TabsTrigger>
        </TabsList>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Content Reports</CardTitle>
              <CardDescription>Manage reported content and take action</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                Array(3)
                  .fill(0)
                  .map((_, i) => (
                    <div key={i} className="mb-4">
                      <Skeleton className="h-24 w-full" />
                    </div>
                  ))
              ) : reports.length > 0 ? (
                <div className="space-y-4">
                  {reports.map((report) => (
                    <Card key={report.id} className={report.resolved ? "bg-muted/50" : ""}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold">Report for: {report.anime.title}</h3>
                            <p className="text-sm text-muted-foreground">Reported by: {report.user.email}</p>
                            <p className="text-sm text-muted-foreground">
                              Date: {new Date(report.created_at).toLocaleDateString()}
                            </p>
                            <p className="mt-2">{report.reason}</p>
                          </div>
                          <div className="flex gap-2">
                            {report.resolved ? (
                              <Button variant="outline" size="sm" onClick={() => handleResolveReport(report.id, false)}>
                                <X className="h-4 w-4 mr-1" />
                                Reopen
                              </Button>
                            ) : (
                              <Button variant="outline" size="sm" onClick={() => handleResolveReport(report.id, true)}>
                                <Check className="h-4 w-4 mr-1" />
                                Resolve
                              </Button>
                            )}
                            <Button variant="destructive" size="sm" onClick={() => handleDeleteAnime(report.anime.id)}>
                              Delete Content
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">No content reports found.</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Recent Users</CardTitle>
              <CardDescription>Recently registered users</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <div key={i} className="mb-4">
                      <Skeleton className="h-12 w-full" />
                    </div>
                  ))
              ) : users.length > 0 ? (
                <div className="space-y-4">
                  {users.map((user) => (
                    <Card key={user.id}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="font-semibold">{user.email}</h3>
                            <p className="text-sm text-muted-foreground">
                              Joined: {new Date(user.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">No users found.</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
