"use client"

import { usePathname } from "next/navigation"
import { Logo } from "@/components/logo"
import { ThemeSwitcher } from "@/components/theme-switcher"

export default function AppHeader() {
  const pathname = usePathname()

  // Don't show header on auth page
  if (pathname === "/auth") {
    return null
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <Logo size="sm" withText={true} />
        <div className="flex flex-1 items-center justify-end">
          <ThemeSwitcher />
        </div>
      </div>
    </header>
  )
}
