"use client"

import { usePathname, useRouter } from "next/navigation"
import { Home, Calendar, Upload, Search, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { Logo } from "@/components/logo"

const navItems = [
  { name: "Home", href: "/", icon: Home },
  { name: "Schedule", href: "/schedule", icon: Calendar },
  { name: "Upload", href: "/upload", icon: Upload },
  { name: "Search", href: "/search", icon: Search },
  { name: "Profile", href: "/profile", icon: User },
]

export default function BottomNav() {
  const pathname = usePathname()
  const router = useRouter()

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border">
      <div className="absolute -top-12 left-1/2 transform -translate-x-1/2">
        <div className="bg-background p-2 rounded-full border border-border shadow-md">
          <Logo size="sm" withText={false} />
        </div>
      </div>
      <nav className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <button
              key={item.name}
              onClick={() => router.push(item.href)}
              className={cn(
                "flex flex-col items-center justify-center w-full h-full transition-colors",
                isActive ? "text-orange-500" : "text-muted-foreground hover:text-foreground",
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs mt-1">{item.name}</span>
            </button>
          )
        })}
      </nav>
    </div>
  )
}
