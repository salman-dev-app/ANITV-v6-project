import Image from "next/image"
import Link from "next/link"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  withText?: boolean
  className?: string
}

export function Logo({ size = "md", withText = true, className = "" }: LogoProps) {
  const sizes = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-24 h-24",
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`relative ${sizes[size]}`}>
        <Image src="/images/anitv-logo.png" alt="AniTV Logo" fill className="object-contain" priority />
      </div>
      {withText && (
        <span className={`font-bold ${size === "lg" ? "text-2xl" : size === "md" ? "text-xl" : "text-base"}`}>
          AniTV
        </span>
      )}
    </div>
  )
}

export function LogoLink({ size = "md", withText = true, className = "" }: LogoProps) {
  return (
    <Link href="/" className={className}>
      <Logo size={size} withText={withText} />
    </Link>
  )
}
