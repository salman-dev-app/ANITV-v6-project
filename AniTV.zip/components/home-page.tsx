"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { getFeaturedAnime, getRecentAnime, getTrendingAnime, getGenres } from "@/lib/services/anime-service"

export default function HomePage() {
  const { toast } = useToast()
  const [currentSlide, setCurrentSlide] = useState(0)
  const [loading, setLoading] = useState(true)
  const [featuredAnime, setFeaturedAnime] = useState<any[]>([])
  const [recentAnime, setRecentAnime] = useState<any[]>([])
  const [trendingAnime, setTrendingAnime] = useState<any[]>([])
  const [genres, setGenres] = useState<string[]>([])

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true)

        // Load data in parallel
        const [featured, recent, trending, genreList] = await Promise.all([
          getFeaturedAnime().catch(() => []),
          getRecentAnime().catch(() => []),
          getTrendingAnime().catch(() => []),
          getGenres().catch(() => []),
        ])

        setFeaturedAnime(featured)
        setRecentAnime(recent)
        setTrendingAnime(trending)
        setGenres(genreList)
      } catch (error) {
        console.error("Error loading home page data:", error)
        toast({
          title: "Error loading data",
          description: "There was a problem loading the content. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [toast])

  useEffect(() => {
    // Auto-rotate carousel only if we have featured anime
    if (featuredAnime.length === 0) return

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredAnime.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [featuredAnime.length])

  const nextSlide = () => {
    if (featuredAnime.length === 0) return
    setCurrentSlide((prev) => (prev + 1) % featuredAnime.length)
  }

  const prevSlide = () => {
    if (featuredAnime.length === 0) return
    setCurrentSlide((prev) => (prev - 1 + featuredAnime.length) % featuredAnime.length)
  }

  // Fallback data for empty states
  const emptyFeatured = [
    { id: 1, title: "No Featured Anime", poster: "/placeholder.svg?height=500&width=300", genre: ["Add Content"] },
  ]

  const displayFeatured = featuredAnime.length > 0 ? featuredAnime : emptyFeatured

  return (
    <div className="pb-6">
      {/* Hero Carousel */}
      <div className="relative h-[50vh] overflow-hidden">
        {loading ? (
          <Skeleton className="h-full w-full" />
        ) : (
          <>
            <div
              className="absolute inset-0 transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              <div className="flex h-full">
                {displayFeatured.map((anime) => (
                  <div key={anime.id} className="relative min-w-full h-full">
                    <Image
                      src={anime.poster || "/placeholder.svg?height=500&width=300"}
                      alt={anime.title}
                      fill
                      className="object-cover"
                      priority
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                    <div className="absolute bottom-0 left-0 p-6 w-full">
                      <h2 className="text-3xl font-bold text-white mb-2">{anime.title}</h2>
                      <div className="flex gap-2 mb-4">
                        {anime.genre?.map((g: string) => (
                          <Badge
                            key={g}
                            variant="secondary"
                            className="bg-orange-500/20 text-orange-500 border-orange-500/50"
                          >
                            {g}
                          </Badge>
                        ))}
                      </div>
                      <Button className="bg-orange-500 hover:bg-orange-600" asChild>
                        <Link href={`/anime/${anime.id}`}>Watch Now</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {displayFeatured.length > 1 && (
              <>
                <button
                  onClick={prevSlide}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-background/80 rounded-full p-2"
                  aria-label="Previous slide"
                >
                  <ChevronLeft className="h-6 w-6" />
                </button>
                <button
                  onClick={nextSlide}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-background/80 rounded-full p-2"
                  aria-label="Next slide"
                >
                  <ChevronRight className="h-6 w-6" />
                </button>
                <div className="absolute bottom-20 left-0 right-0 flex justify-center gap-2">
                  {displayFeatured.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`h-2 w-2 rounded-full ${currentSlide === index ? "bg-orange-500" : "bg-white/50"}`}
                      aria-label={`Go to slide ${index + 1}`}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>

      {/* Recently Added Section */}
      <section className="px-4 mt-8">
        <h2 className="text-2xl font-bold mb-4">Recently Added</h2>
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-4">
            {loading ? (
              Array(4)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="w-[150px] shrink-0">
                    <Skeleton className="h-[200px] w-full rounded-md" />
                    <Skeleton className="h-4 w-full mt-2" />
                    <Skeleton className="h-3 w-3/4 mt-1" />
                  </div>
                ))
            ) : recentAnime.length > 0 ? (
              recentAnime.map((anime) => (
                <Link
                  key={anime.id}
                  href={`/anime/${anime.id}`}
                  className="w-[150px] shrink-0 transition-transform hover:scale-105"
                >
                  <Card className="border-0 overflow-hidden">
                    <div className="relative aspect-[2/3] w-full">
                      <Image
                        src={anime.poster || "/placeholder.svg?height=300&width=200"}
                        alt={anime.title}
                        fill
                        className="object-cover rounded-t-md"
                      />
                    </div>
                    <CardContent className="p-2">
                      <h3 className="font-medium line-clamp-1">{anime.title}</h3>
                      <p className="text-xs text-muted-foreground">By {anime.uploader}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))
            ) : (
              <div className="w-full text-center py-8 text-muted-foreground">No recently added anime found.</div>
            )}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </section>

      {/* Trending Now Section */}
      <section className="px-4 mt-8">
        <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-4">
            {loading ? (
              Array(4)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="w-[150px] shrink-0">
                    <Skeleton className="h-[200px] w-full rounded-md" />
                    <Skeleton className="h-4 w-full mt-2" />
                    <Skeleton className="h-3 w-3/4 mt-1" />
                  </div>
                ))
            ) : trendingAnime.length > 0 ? (
              trendingAnime.map((anime) => (
                <Link
                  key={anime.id}
                  href={`/anime/${anime.id}`}
                  className="w-[150px] shrink-0 transition-transform hover:scale-105"
                >
                  <Card className="border-0 overflow-hidden relative">
                    <div className="absolute top-2 right-2 z-10 bg-orange-500 text-white text-xs px-1.5 py-0.5 rounded-full flex items-center">
                      <Star className="h-3 w-3 mr-0.5 fill-current" />
                      <span>{(anime.views / 1000).toFixed(0)}K</span>
                    </div>
                    <div className="relative aspect-[2/3] w-full">
                      <Image
                        src={anime.poster || "/placeholder.svg?height=300&width=200"}
                        alt={anime.title}
                        fill
                        className="object-cover rounded-t-md"
                      />
                    </div>
                    <CardContent className="p-2">
                      <h3 className="font-medium line-clamp-1">{anime.title}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))
            ) : (
              <div className="w-full text-center py-8 text-muted-foreground">No trending anime found.</div>
            )}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </section>

      {/* Browse by Genre Section */}
      <section className="px-4 mt-8">
        <h2 className="text-2xl font-bold mb-4">Browse by Genre</h2>
        <div className="flex flex-wrap gap-2">
          {loading ? (
            Array(8)
              .fill(0)
              .map((_, i) => <Skeleton key={i} className="h-8 w-20 rounded-full" />)
          ) : genres.length > 0 ? (
            genres.map((genre) => (
              <Link key={genre} href={`/search?genre=${genre}`}>
                <Badge
                  variant="outline"
                  className="px-3 py-1 rounded-full border-orange-500/50 hover:bg-orange-500/10 transition-colors"
                >
                  {genre}
                </Badge>
              </Link>
            ))
          ) : (
            <div className="w-full text-center py-8 text-muted-foreground">No genres found.</div>
          )}
        </div>
      </section>
    </div>
  )
}
