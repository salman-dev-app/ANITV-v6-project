"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Heart, Flag, Send, ExternalLink } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useAuth } from "@/components/auth-provider"
import { getAnimeDetails, checkIsFavorite, toggleFavorite, addComment, reportAnime } from "@/lib/services/anime-service"
import Link from "next/link"

export default function AnimeDetailsPage({ id }: { id: string }) {
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()

  const [animeDetails, setAnimeDetails] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [isFavorite, setIsFavorite] = useState(false)
  const [commentText, setCommentText] = useState("")
  const [isSubmittingComment, setIsSubmittingComment] = useState(false)
  const [reportReason, setReportReason] = useState("")
  const [isSubmittingReport, setIsSubmittingReport] = useState(false)

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true)

        // Load anime details
        const details = await getAnimeDetails(id)
        setAnimeDetails(details)

        // Check if anime is in user's favorites
        if (user) {
          const favorite = await checkIsFavorite(id, user.id)
          setIsFavorite(favorite)
        }
      } catch (error) {
        console.error("Error loading anime details:", error)
        toast({
          title: "Error loading anime",
          description: "There was a problem loading the anime details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      loadData()
    }
  }, [id, user, toast])

  const handleToggleFavorite = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to add this anime to your favorites",
        variant: "destructive",
      })
      return
    }

    try {
      const newFavoriteStatus = await toggleFavorite(id, user.id, isFavorite)
      setIsFavorite(newFavoriteStatus)

      toast({
        title: newFavoriteStatus ? "Added to favorites" : "Removed from favorites",
        description: newFavoriteStatus
          ? "This anime has been added to your favorites"
          : "This anime has been removed from your favorites",
      })
    } catch (error) {
      console.error("Favorite toggle error:", error)
      toast({
        title: "Action failed",
        description: "There was an error processing your request. Please try again.",
        variant: "destructive",
      })
    }
  }

  const submitComment = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to comment",
        variant: "destructive",
      })
      return
    }

    if (!commentText.trim()) {
      toast({
        title: "Empty comment",
        description: "Please enter a comment before submitting",
        variant: "destructive",
      })
      return
    }

    setIsSubmittingComment(true)

    try {
      const newComment = await addComment(id, user.id, commentText)

      // Update the local state with the new comment
      setAnimeDetails({
        ...animeDetails,
        comments: [newComment, ...animeDetails.comments],
      })

      toast({
        title: "Comment posted",
        description: "Your comment has been posted successfully",
      })

      setCommentText("")
    } catch (error) {
      console.error("Comment submission error:", error)
      toast({
        title: "Comment failed",
        description: "There was an error posting your comment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmittingComment(false)
    }
  }

  const submitReport = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to report content",
        variant: "destructive",
      })
      return
    }

    if (!reportReason.trim()) {
      toast({
        title: "Empty reason",
        description: "Please provide a reason for reporting this content",
        variant: "destructive",
      })
      return
    }

    setIsSubmittingReport(true)

    try {
      await reportAnime(id, user.id, reportReason)

      toast({
        title: "Report submitted",
        description: "Your report has been submitted and will be reviewed by our team",
      })

      setReportReason("")
    } catch (error) {
      console.error("Report submission error:", error)
      toast({
        title: "Report failed",
        description: "There was an error submitting your report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmittingReport(false)
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Skeleton className="aspect-[2/3] w-full max-w-[300px] mx-auto md:mx-0" />
            <Skeleton className="h-10 w-full mt-4" />
            <Skeleton className="h-6 w-3/4 mt-4" />
            <Skeleton className="h-6 w-1/2 mt-2" />
          </div>
          <div className="md:col-span-2">
            <Skeleton className="h-10 w-3/4 mb-4" />
            <Skeleton className="h-24 w-full mb-6" />
            <Skeleton className="h-8 w-1/3 mb-4" />
            {Array(3)
              .fill(0)
              .map((_, i) => (
                <Skeleton key={i} className="h-16 w-full mb-3" />
              ))}
          </div>
        </div>
      </div>
    )
  }

  if (!animeDetails) {
    return (
      <div className="container mx-auto px-4 py-6 text-center">
        <h1 className="text-2xl font-bold mb-4">Anime Not Found</h1>
        <p className="text-muted-foreground mb-6">The anime you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/">Return to Home</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Poster and Info */}
        <div className="md:col-span-1">
          <div className="relative aspect-[2/3] w-full max-w-[300px] mx-auto md:mx-0">
            <Image
              src={animeDetails.poster || "/placeholder.svg?height=500&width=300"}
              alt={animeDetails.title}
              fill
              className="object-cover rounded-lg"
              priority
            />
          </div>

          <div className="mt-4 flex justify-between items-center">
            <Button
              variant={isFavorite ? "default" : "outline"}
              className={isFavorite ? "bg-orange-500 hover:bg-orange-600" : ""}
              onClick={handleToggleFavorite}
            >
              <Heart className={`mr-2 h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
              {isFavorite ? "Favorited" : "Add to Favorites"}
            </Button>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Flag className="h-4 w-4 text-destructive" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Report Content</DialogTitle>
                  <DialogDescription>
                    Please provide a reason for reporting this content. Our team will review your report.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={submitReport}>
                  <Textarea
                    placeholder="Reason for reporting..."
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="mt-4"
                    rows={4}
                    required
                  />
                  <DialogFooter className="mt-4">
                    <Button type="submit" variant="destructive" disabled={isSubmittingReport}>
                      {isSubmittingReport ? "Submitting..." : "Submit Report"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="mt-4">
            <h3 className="text-sm font-medium mb-2">Genres</h3>
            <div className="flex flex-wrap gap-2">
              {animeDetails.genre.map((genre: string) => (
                <Badge
                  key={genre}
                  variant="secondary"
                  className="bg-orange-500/10 text-orange-500 border-orange-500/50"
                >
                  {genre}
                </Badge>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <h3 className="text-sm font-medium mb-2">Uploaded by</h3>
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage
                  src={animeDetails.uploader.avatar || "/placeholder.svg?height=50&width=50"}
                  alt={animeDetails.uploader.name}
                />
                <AvatarFallback>{animeDetails.uploader.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-sm">{animeDetails.uploader.name}</span>
            </div>
          </div>

          <div className="mt-4 text-sm text-muted-foreground">
            <p>Uploaded on {new Date(animeDetails.uploadDate).toLocaleDateString()}</p>
            <p>{(animeDetails.views / 1000).toFixed(0)}K views</p>
          </div>
        </div>

        {/* Details and Episodes */}
        <div className="md:col-span-2">
          <h1 className="text-3xl font-bold mb-4">{animeDetails.title}</h1>
          <p className="text-muted-foreground mb-6">{animeDetails.description}</p>

          <h2 className="text-xl font-semibold mb-4">Episodes</h2>
          <div className="space-y-3">
            {animeDetails.episodes.length > 0 ? (
              animeDetails.episodes.map((episode: any) => (
                <Card key={episode.id} className="overflow-hidden">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">
                        Episode {episode.number}: {episode.title}
                      </h3>
                    </div>
                    <Button asChild>
                      <a href={episode.videoUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Watch
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">No episodes available for this anime.</div>
            )}
          </div>

          <Separator className="my-6" />

          <h2 className="text-xl font-semibold mb-4">Comments</h2>
          <div className="space-y-4 mb-6">
            {animeDetails.comments.length > 0 ? (
              animeDetails.comments.map((comment: any) => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={comment.user.avatar || "/placeholder.svg?height=50&width=50"}
                      alt={comment.user.name}
                    />
                    <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-sm">{comment.user.name}</h4>
                      <span className="text-xs text-muted-foreground">
                        {new Date(comment.date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm mt-1">{comment.content}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-muted-foreground">No comments yet. Be the first to comment!</div>
            )}
          </div>

          <form onSubmit={submitComment} className="space-y-4">
            <Textarea
              placeholder="Add a comment..."
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              rows={3}
            />
            <Button type="submit" className="bg-orange-500 hover:bg-orange-600" disabled={isSubmittingComment}>
              <Send className="mr-2 h-4 w-4" />
              {isSubmittingComment ? "Posting..." : "Post Comment"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
