"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Edit2, LogOut, Trash2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/components/auth-provider"
import ProfileEdit from "@/components/profile-edit"

// Mock data - would come from Supabase in production
const uploadedAnime = [
  {
    id: 1,
    title: "Demon Slayer",
    poster: "/placeholder.svg?height=150&width=100",
    uploadDate: "2023-04-15",
    views: 1250000,
  },
  {
    id: 2,
    title: "Attack on Titan",
    poster: "/placeholder.svg?height=150&width=100",
    uploadDate: "2023-03-22",
    views: 980000,
  },
]

const favoriteAnime = [
  {
    id: 3,
    title: "My Hero Academia",
    poster: "/placeholder.svg?height=150&width=100",
    addedDate: "2023-04-10",
  },
  {
    id: 4,
    title: "Jujutsu Kaisen",
    poster: "/placeholder.svg?height=150&width=100",
    addedDate: "2023-03-18",
  },
  {
    id: 5,
    title: "Chainsaw Man",
    poster: "/placeholder.svg?height=150&width=100",
    addedDate: "2023-02-05",
  },
]

export default function ProfilePage() {
  const { toast } = useToast()
  const { user, signOut, isLoading } = useAuth()
  const supabase = createClient()

  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  const handleLogout = async () => {
    setIsLoggingOut(true)
    try {
      await signOut()

      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account",
      })
    } catch (error) {
      console.error("Logout error:", error)
      toast({
        title: "Logout failed",
        description: "There was an error logging out. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoggingOut(false)
    }
  }

  const handleDeleteAnime = async (animeId: number) => {
    try {
      // In a real app, this would be a Supabase delete
      // await supabase.from('anime').delete().eq('id', animeId)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))

      toast({
        title: "Anime deleted",
        description: "The anime has been deleted successfully",
      })

      // Update UI (in a real app, we would refetch data)
    } catch (error) {
      console.error("Delete error:", error)
      toast({
        title: "Delete failed",
        description: "There was an error deleting the anime. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRemoveFavorite = async (animeId: number) => {
    try {
      // In a real app, this would be a Supabase delete
      // await supabase.from('favorites').delete().eq('anime_id', animeId).eq('user_id', user.id)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))

      toast({
        title: "Removed from favorites",
        description: "The anime has been removed from your favorites",
      })

      // Update UI (in a real app, we would refetch data)
    } catch (error) {
      console.error("Remove favorite error:", error)
      toast({
        title: "Remove failed",
        description: "There was an error removing the anime from favorites. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="text-center py-12">
          <p>Please sign in to view your profile.</p>
          <Button variant="link" asChild className="mt-2">
            <Link href="/auth">Sign In</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <Card className="mb-6">
        {isEditing ? (
          <ProfileEdit onCancel={() => setIsEditing(false)} />
        ) : (
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage
                  src={user.user_metadata?.avatar_url || "/placeholder.svg"}
                  alt={user.user_metadata?.name || user.email || "User"}
                />
                <AvatarFallback>
                  {user.user_metadata?.name?.[0]?.toUpperCase() || user.email?.[0].toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="text-center sm:text-left">
                <h1 className="text-2xl font-bold">{user.user_metadata?.name || "Anime Fan"}</h1>
                <p className="text-muted-foreground">{user.email}</p>
              </div>
              <div className="flex gap-2 ml-auto mt-4 sm:mt-0">
                <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                  <Edit2 className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm" disabled={isLoggingOut}>
                      <LogOut className="h-4 w-4 mr-2" />
                      {isLoggingOut ? "Logging out..." : "Logout"}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure you want to logout?</AlertDialogTitle>
                      <AlertDialogDescription>
                        You will need to login again to access your account.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleLogout}>Logout</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      <Tabs defaultValue="uploaded" className="w-full">
        <TabsList className="w-full">
          <TabsTrigger value="uploaded" className="flex-1">
            Uploaded Anime
          </TabsTrigger>
          <TabsTrigger value="favorites" className="flex-1">
            Favorite Anime
          </TabsTrigger>
        </TabsList>

        <TabsContent value="uploaded" className="mt-4">
          {uploadedAnime.length > 0 ? (
            <div className="space-y-4">
              {uploadedAnime.map((anime) => (
                <Card key={anime.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex">
                      <div className="relative h-[100px] w-[70px] shrink-0">
                        <Image
                          src={anime.poster || "/placeholder.svg"}
                          alt={anime.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 p-4 flex flex-col justify-between">
                        <div>
                          <h3 className="font-semibold">{anime.title}</h3>
                          <p className="text-xs text-muted-foreground">
                            Uploaded on {new Date(anime.uploadDate).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-muted-foreground">{(anime.views / 1000).toFixed(0)}K views</p>
                        </div>
                        <div className="flex gap-2 mt-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/upload?edit=${anime.id}`}>
                              <Edit2 className="h-3 w-3 mr-1" />
                              Edit
                            </Link>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                <Trash2 className="h-3 w-3 mr-1" />
                                Delete
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure you want to delete this anime?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. This will permanently delete the anime and all
                                  associated data.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteAnime(anime.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>You haven't uploaded any anime yet.</p>
              <Button variant="link" asChild className="mt-2">
                <Link href="/upload">Upload your first anime</Link>
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="favorites" className="mt-4">
          {favoriteAnime.length > 0 ? (
            <div className="space-y-4">
              {favoriteAnime.map((anime) => (
                <Card key={anime.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex">
                      <div className="relative h-[100px] w-[70px] shrink-0">
                        <Image
                          src={anime.poster || "/placeholder.svg"}
                          alt={anime.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 p-4 flex flex-col justify-between">
                        <div>
                          <h3 className="font-semibold">{anime.title}</h3>
                          <p className="text-xs text-muted-foreground">
                            Added on {new Date(anime.addedDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex gap-2 mt-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/anime/${anime.id}`}>View</Link>
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleRemoveFavorite(anime.id)}>
                            <Trash2 className="h-3 w-3 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>You haven't added any anime to your favorites yet.</p>
              <Button variant="link" asChild className="mt-2">
                <Link href="/">Browse anime</Link>
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
