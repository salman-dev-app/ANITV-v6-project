export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      anime: {
        Row: {
          id: number
          created_at: string
          title: string
          description: string
          poster_url: string
          uploader_id: string
          views: number
        }
        Insert: {
          id?: number
          created_at?: string
          title: string
          description: string
          poster_url: string
          uploader_id: string
          views?: number
        }
        Update: {
          id?: number
          created_at?: string
          title?: string
          description?: string
          poster_url?: string
          uploader_id?: string
          views?: number
        }
      }
      episodes: {
        Row: {
          id: number
          created_at: string
          anime_id: number
          title: string
          video_url: string
          episode_number: number
        }
        Insert: {
          id?: number
          created_at?: string
          anime_id: number
          title: string
          video_url: string
          episode_number: number
        }
        Update: {
          id?: number
          created_at?: string
          anime_id?: number
          title?: string
          video_url?: string
          episode_number?: number
        }
      }
      genres: {
        Row: {
          id: number
          name: string
        }
        Insert: {
          id?: number
          name: string
        }
        Update: {
          id?: number
          name?: string
        }
      }
      anime_genres: {
        Row: {
          id: number
          anime_id: number
          genre_id: number
        }
        Insert: {
          id?: number
          anime_id: number
          genre_id: number
        }
        Update: {
          id?: number
          anime_id?: number
          genre_id?: number
        }
      }
      favorites: {
        Row: {
          id: number
          user_id: string
          anime_id: number
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          anime_id: number
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          anime_id?: number
          created_at?: string
        }
      }
      comments: {
        Row: {
          id: number
          anime_id: number
          user_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: number
          anime_id: number
          user_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: number
          anime_id?: number
          user_id?: string
          content?: string
          created_at?: string
        }
      }
      schedules: {
        Row: {
          id: number
          anime_id: number
          release_date: string
          type: string
        }
        Insert: {
          id?: number
          anime_id: number
          release_date: string
          type: string
        }
        Update: {
          id?: number
          anime_id?: number
          release_date?: string
          type?: string
        }
      }
      reports: {
        Row: {
          id: number
          anime_id: number
          user_id: string
          reason: string
          created_at: string
          resolved: boolean
        }
        Insert: {
          id?: number
          anime_id: number
          user_id: string
          reason: string
          created_at?: string
          resolved?: boolean
        }
        Update: {
          id?: number
          anime_id?: number
          user_id?: string
          reason?: string
          created_at?: string
          resolved?: boolean
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
