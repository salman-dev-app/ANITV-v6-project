import { createClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/database.types"

type Anime = Database["public"]["Tables"]["anime"]["Row"]
type Episode = Database["public"]["Tables"]["episodes"]["Row"]
type Genre = Database["public"]["Tables"]["genres"]["Row"]

export async function getFeaturedAnime() {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("anime")
    .select(`
      *,
      anime_genres!inner (
        genres (
          name
        )
      )
    `)
    .order("views", { ascending: false })
    .limit(3)

  if (error) {
    console.error("Error fetching featured anime:", error)
    throw error
  }

  // Transform the data to match the expected format
  return data.map((anime) => ({
    id: anime.id,
    title: anime.title,
    poster: anime.poster_url,
    genre: anime.anime_genres.map((ag: any) => ag.genres.name),
  }))
}

export async function getRecentAnime() {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("anime")
    .select(`
      *,
      anime_genres (
        genres (
          name
        )
      ),
      uploader:uploader_id (
        email
      )
    `)
    .order("created_at", { ascending: false })
    .limit(4)

  if (error) {
    console.error("Error fetching recent anime:", error)
    throw error
  }

  // Transform the data to match the expected format
  return data.map((anime) => ({
    id: anime.id,
    title: anime.title,
    poster: anime.poster_url,
    uploader: anime.uploader?.email?.split("@")[0] || "Unknown",
    genre: anime.anime_genres.map((ag: any) => ag.genres.name),
  }))
}

export async function getTrendingAnime() {
  const supabase = createClient()

  const { data, error } = await supabase.from("anime").select("*").order("views", { ascending: false }).limit(4)

  if (error) {
    console.error("Error fetching trending anime:", error)
    throw error
  }

  // Transform the data to match the expected format
  return data.map((anime) => ({
    id: anime.id,
    title: anime.title,
    poster: anime.poster_url,
    views: anime.views,
  }))
}

export async function getGenres() {
  const supabase = createClient()

  const { data, error } = await supabase.from("genres").select("name").order("name")

  if (error) {
    console.error("Error fetching genres:", error)
    throw error
  }

  return data.map((genre) => genre.name)
}

export async function getAnimeDetails(id: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("anime")
    .select(`
      *,
      anime_genres (
        genres (
          name
        )
      ),
      uploader:uploader_id (
        id,
        email
      ),
      episodes (
        id,
        title,
        video_url,
        episode_number
      ),
      comments (
        id,
        content,
        created_at,
        user:user_id (
          id,
          email
        )
      )
    `)
    .eq("id", id)
    .single()

  if (error) {
    console.error(`Error fetching anime details for ID ${id}:`, error)
    throw error
  }

  if (!data) {
    throw new Error(`Anime with ID ${id} not found`)
  }

  // Transform the data to match the expected format
  return {
    id: data.id,
    title: data.title,
    description: data.description,
    poster: data.poster_url,
    uploader: {
      id: data.uploader.id,
      name: data.uploader.email.split("@")[0],
      avatar: "/placeholder.svg?height=50&width=50",
    },
    uploadDate: data.created_at,
    views: data.views,
    genre: data.anime_genres.map((ag: any) => ag.genres.name),
    episodes: data.episodes.map((ep: any) => ({
      id: ep.id,
      number: ep.episode_number,
      title: ep.title,
      videoUrl: ep.video_url,
    })),
    comments: data.comments.map((comment: any) => ({
      id: comment.id,
      user: {
        id: comment.user.id,
        name: comment.user.email.split("@")[0],
        avatar: "/placeholder.svg?height=50&width=50",
      },
      content: comment.content,
      date: comment.created_at,
    })),
  }
}

export async function checkIsFavorite(animeId: string, userId: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("favorites")
    .select("id")
    .eq("anime_id", animeId)
    .eq("user_id", userId)
    .maybeSingle()

  if (error) {
    console.error("Error checking favorite status:", error)
    throw error
  }

  return !!data
}

export async function toggleFavorite(animeId: string, userId: string, isFavorite: boolean) {
  const supabase = createClient()

  if (isFavorite) {
    // Remove from favorites
    const { error } = await supabase.from("favorites").delete().eq("anime_id", animeId).eq("user_id", userId)

    if (error) {
      console.error("Error removing favorite:", error)
      throw error
    }
  } else {
    // Add to favorites
    const { error } = await supabase.from("favorites").insert({
      anime_id: Number.parseInt(animeId),
      user_id: userId,
    })

    if (error) {
      console.error("Error adding favorite:", error)
      throw error
    }
  }

  return !isFavorite
}

export async function addComment(animeId: string, userId: string, content: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("comments")
    .insert({
      anime_id: Number.parseInt(animeId),
      user_id: userId,
      content,
    })
    .select(`
      id,
      content,
      created_at,
      user:user_id (
        id,
        email
      )
    `)
    .single()

  if (error) {
    console.error("Error adding comment:", error)
    throw error
  }

  return {
    id: data.id,
    user: {
      id: data.user.id,
      name: data.user.email.split("@")[0],
      avatar: "/placeholder.svg?height=50&width=50",
    },
    content: data.content,
    date: data.created_at,
  }
}

export async function reportAnime(animeId: string, userId: string, reason: string) {
  const supabase = createClient()

  const { error } = await supabase.from("reports").insert({
    anime_id: Number.parseInt(animeId),
    user_id: userId,
    reason,
  })

  if (error) {
    console.error("Error reporting anime:", error)
    throw error
  }

  return true
}
