import { createBrowserClient } from "@supabase/ssr"
import type { Database } from "@/lib/database.types"

let client: ReturnType<typeof createBrowserClient<Database>> | null = null

export function createClient() {
  // Only create the client in browser environments
  if (typeof window === "undefined") {
    return null as any // Return null for SSR - this prevents errors during build
  }

  if (client) return client

  // Ensure environment variables are available
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("Missing Supabase environment variables")
    return null as any
  }

  try {
    client = createBrowserClient<Database>(supabaseUrl, supabaseAnonKey)
    return client
  } catch (error) {
    console.error("Error creating Supabase client:", error)
    return null as any
  }
}
