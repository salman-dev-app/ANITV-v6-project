# Deployment Instructions for AniTV

## Prerequisites
- Vercel account
- Supabase account with a project set up

## Environment Variables
Make sure to set the following environment variables in your Vercel project:

- `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase anonymous key
- `SUPABASE_SERVICE_ROLE_KEY`: Your Supabase service role key

## Deployment Steps

1. Connect your GitHub repository to Vercel
2. Configure the environment variables
3. Deploy the project
4. After deployment, run the following setup endpoints in order:
   - `https://your-domain.vercel.app/api/setup-db` (Set up database tables)
   - `https://your-domain.vercel.app/api/setup-storage` (Set up storage buckets)
   - `https://your-domain.vercel.app/api/seed-db` (Seed the database with sample data)

## Storage Configuration

The application uses Supabase Storage for file uploads. Make sure your Supabase project has the following storage buckets:

- `avatars`: For user profile pictures
- `posters`: For anime poster images

These buckets should be set to public access to allow images to be displayed in the app.

## Troubleshooting

If you encounter deployment issues:

1. Check the Vercel build logs for errors
2. Ensure all environment variables are correctly set
3. Verify that your Supabase project is properly configured
4. Check that the database tables and storage buckets have been created correctly
5. For upload issues, check the browser console for errors and verify that the Supabase storage buckets are properly configured
