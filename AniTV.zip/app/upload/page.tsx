import AppLayout from "@/components/app-layout"
import UploadPage from "@/components/upload-page"

export default function Upload() {
  return (
    <AppLayout>
      <UploadPage />
    </AppLayout>
  )
}
