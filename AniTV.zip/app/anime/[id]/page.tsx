import AppLayout from "@/components/app-layout"
import AnimeDetailsPage from "@/components/anime-details-page"

export default function AnimeDetails({ params }: { params: { id: string } }) {
  return (
    <AppLayout>
      <AnimeDetailsPage id={params.id} />
    </AppLayout>
  )
}
