import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createClient()

    // Create storage buckets if they don't exist
    const buckets = ["avatars", "posters"]

    for (const bucket of buckets) {
      // Check if bucket exists
      const { data: existingBuckets } = await supabase.storage.listBuckets()
      const bucketExists = existingBuckets?.some((b) => b.name === bucket)

      if (!bucketExists) {
        // Create bucket
        const { error } = await supabase.storage.createBucket(bucket, {
          public: true,
          fileSizeLimit: 10485760, // 10MB
        })

        if (error) {
          console.error(`Error creating bucket ${bucket}:`, error)
        }
      }

      // Update bucket to be public
      const { error } = await supabase.storage.updateBucket(bucket, {
        public: true,
      })

      if (error) {
        console.error(`Error updating bucket ${bucket}:`, error)
      }
    }

    return NextResponse.json({ success: true, message: "Storage buckets setup completed successfully" })
  } catch (error) {
    console.error("Storage setup error:", error)
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 })
  }
}
