import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createClient()

    // Create tables

    // Genres table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS genres (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE
      )
    `)

    // Anime table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS anime (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        poster_url TEXT NOT NULL,
        uploader_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        views INTEGER DEFAULT 0
      )
    `)

    // Episodes table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS episodes (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        video_url TEXT NOT NULL,
        episode_number INTEGER NOT NULL
      )
    `)

    // Anime-Genres junction table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS anime_genres (
        id SERIAL PRIMARY KEY,
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        genre_id INTEGER REFERENCES genres(id) ON DELETE CASCADE,
        UNIQUE(anime_id, genre_id)
      )
    `)

    // Favorites table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS favorites (
        id SERIAL PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(user_id, anime_id)
      )
    `)

    // Comments table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS comments (
        id SERIAL PRIMARY KEY,
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        content TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `)

    // Schedules table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS schedules (
        id SERIAL PRIMARY KEY,
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        release_date DATE NOT NULL,
        type TEXT NOT NULL
      )
    `)

    // Reports table
    await supabase.query(`
      CREATE TABLE IF NOT EXISTS reports (
        id SERIAL PRIMARY KEY,
        anime_id INTEGER REFERENCES anime(id) ON DELETE CASCADE,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        reason TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        resolved BOOLEAN DEFAULT FALSE
      )
    `)

    // Insert default genres
    await supabase
      .from("genres")
      .upsert(
        [
          { name: "Action" },
          { name: "Adventure" },
          { name: "Comedy" },
          { name: "Drama" },
          { name: "Fantasy" },
          { name: "Horror" },
          { name: "Mystery" },
          { name: "Romance" },
          { name: "Sci-Fi" },
          { name: "Slice of Life" },
          { name: "Sports" },
          { name: "Supernatural" },
          { name: "Thriller" },
        ],
        { onConflict: "name" },
      )

    return NextResponse.json({ success: true, message: "Database setup completed successfully" })
  } catch (error) {
    console.error("Database setup error:", error)
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 })
  }
}
