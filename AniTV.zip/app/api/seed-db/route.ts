import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createClient()

    // Sample anime data
    const animeData = [
      {
        title: "Demon Slayer",
        description:
          "In a world where demons feed on humans and plague the land, a young boy named Tanjirou Kamado becomes a demon slayer after his family is slaughtered and his sister is turned into a demon.",
        poster_url: "/placeholder.svg?height=500&width=300",
        genres: ["Action", "Fantasy", "Historical", "Supernatural"],
        episodes: [
          { title: "Cruelty", video_url: "https://example.com/video1", episode_number: 1 },
          { title: "Trainer Sakonji Urokodaki", video_url: "https://example.com/video2", episode_number: 2 },
          { title: "Sabito and Makomo", video_url: "https://example.com/video3", episode_number: 3 },
          { title: "Final Selection", video_url: "https://example.com/video4", episode_number: 4 },
        ],
      },
      {
        title: "Attack on Titan",
        description:
          "Humanity lives inside cities surrounded by enormous walls due to the Titans, gigantic humanoid creatures who devour humans seemingly without reason.",
        poster_url: "/placeholder.svg?height=500&width=300",
        genres: ["Action", "Drama", "Fantasy", "Mystery"],
        episodes: [
          { title: "To You, 2,000 Years From Now", video_url: "https://example.com/aot1", episode_number: 1 },
          { title: "That Day", video_url: "https://example.com/aot2", episode_number: 2 },
          { title: "A Dim Light Amid Despair", video_url: "https://example.com/aot3", episode_number: 3 },
        ],
      },
      {
        title: "My Hero Academia",
        description:
          "In a world where people with superpowers known as 'Quirks' are the norm, Izuku Midoriya has dreams of becoming a hero despite being bullied for not having a Quirk.",
        poster_url: "/placeholder.svg?height=500&width=300",
        genres: ["Action", "Comedy", "Superhero"],
        episodes: [
          { title: "Izuku Midoriya: Origin", video_url: "https://example.com/mha1", episode_number: 1 },
          { title: "What It Takes to Be a Hero", video_url: "https://example.com/mha2", episode_number: 2 },
          { title: "Roaring Muscles", video_url: "https://example.com/mha3", episode_number: 3 },
        ],
      },
      {
        title: "Jujutsu Kaisen",
        description:
          "Yuji Itadori, a high school student with exceptional physical abilities, joins his school's Occult Club to avoid participating in track. When the club accidentally unseals a cursed object, Yuji swallows it to protect his friends.",
        poster_url: "/placeholder.svg?height=500&width=300",
        genres: ["Action", "Supernatural", "Horror"],
        episodes: [
          { title: "Ryomen Sukuna", video_url: "https://example.com/jjk1", episode_number: 1 },
          { title: "For Myself", video_url: "https://example.com/jjk2", episode_number: 2 },
          { title: "Girl of Steel", video_url: "https://example.com/jjk3", episode_number: 3 },
        ],
      },
      {
        title: "One Piece",
        description:
          "Follows the adventures of Monkey D. Luffy and his pirate crew in order to find the greatest treasure ever left by the legendary Pirate, Gold Roger.",
        poster_url: "/placeholder.svg?height=500&width=300",
        genres: ["Action", "Adventure", "Comedy", "Fantasy"],
        episodes: [
          {
            title: "I'm Luffy! The Man Who's Gonna Be King of the Pirates!",
            video_url: "https://example.com/op1",
            episode_number: 1,
          },
          {
            title: "Enter the Great Swordsman! Pirate Hunter Roronoa Zoro!",
            video_url: "https://example.com/op2",
            episode_number: 2,
          },
          {
            title: "Morgan versus Luffy! Who's the Mysterious Pretty Girl?",
            video_url: "https://example.com/op3",
            episode_number: 3,
          },
        ],
      },
    ]

    // Get the first user from the database to use as uploader
    const { data: users } = await supabase.auth.admin.listUsers()
    const uploaderId = users?.users[0]?.id

    if (!uploaderId) {
      return NextResponse.json({ success: false, error: "No users found to use as uploader" }, { status: 400 })
    }

    // Insert anime data
    for (const anime of animeData) {
      // Insert anime
      const { data: animeRecord, error: animeError } = await supabase
        .from("anime")
        .insert({
          title: anime.title,
          description: anime.description,
          poster_url: anime.poster_url,
          uploader_id: uploaderId,
          views: Math.floor(Math.random() * 1000000) + 100000, // Random view count
        })
        .select()
        .single()

      if (animeError) {
        console.error(`Error inserting anime ${anime.title}:`, animeError)
        continue
      }

      // Insert episodes
      for (const episode of anime.episodes) {
        const { error: episodeError } = await supabase.from("episodes").insert({
          anime_id: animeRecord.id,
          title: episode.title,
          video_url: episode.video_url,
          episode_number: episode.episode_number,
        })

        if (episodeError) {
          console.error(`Error inserting episode ${episode.title}:`, episodeError)
        }
      }

      // Insert genre relationships
      for (const genreName of anime.genres) {
        // Get genre ID
        const { data: genreData, error: genreError } = await supabase
          .from("genres")
          .select("id")
          .eq("name", genreName)
          .single()

        if (genreError) {
          console.error(`Error finding genre ${genreName}:`, genreError)
          continue
        }

        // Insert anime-genre relationship
        const { error: relationError } = await supabase.from("anime_genres").insert({
          anime_id: animeRecord.id,
          genre_id: genreData.id,
        })

        if (relationError) {
          console.error(`Error inserting genre relation for ${genreName}:`, relationError)
        }
      }

      // Add a sample comment
      const { error: commentError } = await supabase.from("comments").insert({
        anime_id: animeRecord.id,
        user_id: uploaderId,
        content: `This is a great anime! I love ${anime.title}.`,
      })

      if (commentError) {
        console.error(`Error inserting comment for ${anime.title}:`, commentError)
      }

      // Add to schedule
      const today = new Date()
      const releaseDate = new Date(today)
      releaseDate.setDate(today.getDate() + Math.floor(Math.random() * 7)) // Random day in the next week

      const { error: scheduleError } = await supabase.from("schedules").insert({
        anime_id: animeRecord.id,
        release_date: releaseDate.toISOString().split("T")[0],
        type: ["TV", "Movie", "OVA"][Math.floor(Math.random() * 3)], // Random type
      })

      if (scheduleError) {
        console.error(`Error inserting schedule for ${anime.title}:`, scheduleError)
      }
    }

    return NextResponse.json({ success: true, message: "Database seeded successfully" })
  } catch (error) {
    console.error("Database seeding error:", error)
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 })
  }
}
