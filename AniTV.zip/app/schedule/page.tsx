import AppLayout from "@/components/app-layout"
import SchedulePage from "@/components/schedule-page"

export default function Schedule() {
  return (
    <AppLayout>
      <SchedulePage />
    </AppLayout>
  )
}
