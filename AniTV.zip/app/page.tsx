import { createClient } from "@/lib/supabase/server"
import AppLayout from "@/components/app-layout"
import HomePage from "@/components/home-page"
import ErrorBoundary from "@/components/error-boundary"

export default async function Home() {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Uncomment to require authentication
  // if (!session) {
  //   redirect('/auth')
  // }

  return (
    <AppLayout>
      <ErrorBoundary>
        <HomePage />
      </ErrorBoundary>
    </AppLayout>
  )
}
